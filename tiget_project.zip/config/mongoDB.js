const atlasURL = "mongodb+srv://ashisland:paranoid@cluster0.u7cnyfy.mongodb.net/tiget?retryWrites=true&w=majority";
export {atlasURL}

// export { atlasURL };
